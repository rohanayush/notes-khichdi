export interface Articles{
    id1:string;
    title:string;
    description:string;
}