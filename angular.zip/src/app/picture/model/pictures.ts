export interface Pictures{
    id:string;
    title:string;
    description:string;
    picture:any;
}