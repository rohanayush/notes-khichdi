import { LngLatBounds, LngLatLike } from "maplibre-gl";

export interface Maps {
    id:string;
    title:string;
    center: any;
    zoom: any;
    bbox: any;
  }