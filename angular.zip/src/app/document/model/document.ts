export interface Documents{
    id:string;
    title:string;
    type:string;
    document:any;
}