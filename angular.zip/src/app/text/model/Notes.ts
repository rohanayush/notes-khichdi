export interface Notes{
    id:string;
    description:string;
}